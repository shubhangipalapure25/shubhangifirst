﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using NewFashion.DALayer;
using NewFashion.Models;

namespace NewFashion.Controllers
{
    public class WomenController : ApiController
    {
        private AccessCls cls = new AccessCls();
        // GET: api/Women
        public IEnumerable<Women> Get()
        {
            return cls.retWList();

        }

        // GET: api/Women/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Women
       // Womenmessage wmsg = new Womenmessage();
        public Message1 Post([FromBody]Women w)
        {
            Message1 obj_message1 = new Message1();
            if (ModelState.IsValid)
            {
                return cls.AddWomen(w);
            }
            else
            {
                obj_message1.message = "Enter all fields";
                return obj_message1;
            }
         
        }

        // PUT: api/Women/5
        public Women Put([FromBody]Women w)
        {
            return cls.UpWomen(w);
        }

        // DELETE: api/Women/5
        public void Delete(string id)
        {
            cls.DelWomen(id);
        }
    }
}
