﻿using NewFashion.DALayer;
using NewFashion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;



namespace NewFashion.Controllers
{
    public class MenController : ApiController
    {
        private AccessCls cls = new AccessCls();
        // GET: api/Men
        public IEnumerable<Men> Get()
        {
            return cls.retMList();
        }

        // GET: api/Men/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Men
        
        public Message1 Post([FromBody]Men m)
        {
            Message1 obj_message1 = new Message1();
            if (ModelState.IsValid)
            {
                return cls.AddMen(m);
            }
            else
            {
                obj_message1.message = "Enter all fields";
                return obj_message1;
            }
        }

        // PUT: api/Men/5
        public Men Put( [FromBody]Men m)
        {
            return cls.UpMen(m);
        }

        // DELETE: api/Men/5
        public void Delete(string s)
        {
            cls.DelMen(s);
        }
    }
}
