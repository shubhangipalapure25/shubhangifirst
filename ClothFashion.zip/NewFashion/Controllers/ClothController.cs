﻿using NewFashion.DALayer;
using NewFashion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace NewFashion.Controllers
{
    public class ClothController : ApiController
    {
        private AccessCls cls = new AccessCls();
        // GET: api/Cloth
        public IEnumerable<Cloth> Get()
        {
            return cls.retList();

        }

        // GET: api/Cloth/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Cloth
      
        public Message1 Post([FromBody]Cloth c)
        {
            Message1 message1 = new Message1();
           
            if (ModelState.IsValid)
            {
                return cls.AddCloth(c);
            }
            else
            {
            message1.message="Please enter all field";

                return message1;
            }
           
        }

        // PUT: api/Cloth/5
        public Cloth Put( [FromBody]Cloth c)
        {
            return cls.UpCloth(c);
        }

        // DELETE: api/Cloth/5
        public void Delete(int id)
        {
            cls.DelCloth(id);
        }
    }
}
