﻿using NewFashion.DALayer;
using NewFashion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NewFashion.Controllers
{
    public class KidsController : ApiController
    {
        private AccessCls cls = new AccessCls();
        // GET: api/Kids
        public IEnumerable<Kids> Get()
        {
            return cls.retKList();
        }

        // GET: api/Kids/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Kids
        public Message1 Post([FromBody]Kids k)
        {
            Message1 obj_message = new Message1();
          if (ModelState.IsValid)
           {

                return cls.AddKid(k);
           }
             else
             {
                
                //k.Kid = "";
                //k.Name = "";
                //k.Brand = "";
                //k.ClothType = "";
                //k.Price = 0;
                //k.Cid = 0;
                obj_message.message = "please enter all fields ";
                return obj_message;

                }
            }

        // PUT: api/Kids/5
        public Kids Put( [FromBody]Kids k)
        {
            return cls.UpKid(k);
        }

        // DELETE: api/Kids/5
        public void Delete(string id)
        {
            cls.DelKid(id);
        }
    }
}
