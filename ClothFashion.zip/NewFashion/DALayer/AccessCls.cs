﻿using NewFashion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace NewFashion.DALayer
{
    public class AccessCls : IAccessDb
    {
        SqlConnection con = null;
        Message1 obj_message1 = new Message1();

        public AccessCls()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Fashion;Integrated Security=True");
        }
        public Message1 AddCloth(Cloth c)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("insert into Cloth values (" + c.Cid + ",'" + c.Category + "')", con);
                con.Open();
                using (con)
                {
                    cmd.ExecuteNonQuery();
                }
                obj_message1.message = "Data Inserted Sucessfully";
            }
            catch
            {
                obj_message1.message = "Data not Inserted Sucessfully";
            }
            //Message1 obj_message1 = new Message1();
           
            return obj_message1;
        }

        public Message1 AddKid(Kids k)
        {
            //kidsmessage obj_kidsmessage = new kidsmessage();

            try
            {
                string query = "insert into Kids values('" + k.Kid + "','" + k.Name + "','" + k.Brand + "','" + k.ClothType + "'," + k.Price + "," + k.Cid + ")";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                using (con)
                {
                    cmd.ExecuteNonQuery();
                }
                obj_message1.message = "Data Inserted Sucessfully";
            }
            catch
            {
                obj_message1.message = "Data Insertion Failed";

            }

            return obj_message1;
        }

        public Message1 AddMen(Men m)
        {

            try
            {
                string query = "insert into Men values('" + m.Mid + "','" + m.Name + "','" + m.Brand + "','" + m.ClothType + "'," + m.Price + "," + m.Cid + ")";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                using (con)
                {
                    cmd.ExecuteNonQuery();

                }
                obj_message1.message = "Record inserted";
            }
            catch
                {
                obj_message1.message = "Record  not inserted";
            }
            
            return obj_message1;
        }

        public Message1 AddWomen(Women w)
        {
            Message1 msg1 = new Message1();
            try
            {
                string query = "insert into Women values('" + w.Wid + "','" + w.Name + "','" + w.Brand + "','" + w.ClothType + "','" + w.Price + "'," + w.Cid + ")";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                using (con)
                {
                    cmd.ExecuteNonQuery();
                }
                 msg1.message = "Record inserted";
               // return w;

            }
            catch
            {
                msg1.message = "Record not inserted";
            }
            return msg1;

        }

        public void DelCloth(int i)
        {
            SqlCommand cmd = new SqlCommand("delete from Cloth where Cid=" + i + "", con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }

        public void DelKid(string k)
        {
            SqlCommand cmd = new SqlCommand("delete from Kids where Kid='" + k + "'", con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }

        public void DelMen(string s)
        {

            string query = "delete from Men where Mid='" + s + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }

        public void DelWomen(string s)
        {
            string query = "delete from Women where Wid='" + s + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }

        public List<Kids> retKList()
        {
            List<Kids> ls = new List<Kids>();
            SqlDataAdapter da = new SqlDataAdapter("select * from Kids", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {

                Kids kk = new Kids();
                kk.Kid = item["Kid"].ToString();
                kk.Name = item["Name"].ToString();
                kk.Brand = item["Brand"].ToString();
                kk.ClothType = item["Cloth Type"].ToString();
                kk.Price = int.Parse(item["Price"].ToString());
                kk.Cid = int.Parse(item["Cid"].ToString());
                ls.Add(kk);
            }
              return ls;
        }

        public List<Cloth> retList()
        {
            List<Cloth> ls = new List<Cloth>();
            SqlDataAdapter da = new SqlDataAdapter("select * from Cloth", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                Cloth cc = new Cloth();
                cc.Cid = int.Parse(item["cid"].ToString());
                cc.Category = item["category"].ToString();
                ls.Add(cc);

            }
                 return ls;
        }

        public List<Men> retMList()
        {
            List<Men> ls = new List<Men>();
            SqlDataAdapter da = new SqlDataAdapter("select * from Men", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)

            {
                Men mm = new Men();
                mm.Mid = item["Mid"].ToString();
                mm.Name = item["Name"].ToString();
                mm.Brand = item["Brand"].ToString();
                mm.ClothType = item["Cloth Type"].ToString();
                mm.Price = int.Parse(item["Price"].ToString());
                mm.Cid = int.Parse(item["Cid"].ToString());
                ls.Add(mm);
            }
            return ls;
        }

        public List<Women> retWList()
        {
            List<Women> ls = new List<Women>();
          

            SqlDataAdapter da = new SqlDataAdapter("select * from Women", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                Women ww = new Women();
                ww.Wid = item["Wid"].ToString();
                ww.Name = item["Name"].ToString();
                ww.Brand = item["Brand"].ToString();
                ww.ClothType = item["Cloth Type"].ToString();
                ww.Price = int.Parse(item["Price"].ToString());
                ww.Cid = int.Parse(item["Cid"].ToString());
                ls.Add(ww);

            }
            return ls;

        }

        public Cloth UpCloth(Cloth c)
        {
            string query = "update Cloth set Category='" + c.Category + "' where Cid=" + c.Cid + "";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
            return c;
        }

        public Kids UpKid(Kids k)
        {
            string query = "update Kids set Name='" + k.Name + "', Brand='" + k.Brand + "', [Cloth Type]='" + k.ClothType + "',Price=" + k.Price + ", Cid=" + k.Cid + " where Kid='" + k.Kid + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
            return k;
        }

        public Men UpMen(Men m)
        {
            string query = "update Men set Name='" + m.Name + "',Brand='" + m.Brand + "',[Cloth Type]='" + m.ClothType + "',Price='" + m.Price + "'  where Mid='" + m.Mid + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
            return m;
        }
            

        public Women UpWomen(Women w)
        {
            string query = "update  Women set Name='" + w.Name + "',Brand='" + w.Brand + "',[Cloth Type]='" + w.ClothType + "',Price='" + w.Price + "' where Wid='" + w.Wid + "' ";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
            return w;
        }
    }

       
      
  }
