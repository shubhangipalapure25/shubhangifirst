﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewFashion.Models;

namespace NewFashion.DALayer
{
    interface IAccessDb
    {
        List<Cloth> retList();
        Message1 AddCloth(Cloth c);
        Cloth UpCloth(Cloth c);
        void DelCloth(int i);

        List<Women> retWList();
        Message1 AddWomen(Women w);
        Women UpWomen(Women w);
        void DelWomen(String s);

        List<Men> retMList();
        Message1 AddMen(Men m);
        Men UpMen(Men m);
        void DelMen(string s);

        List<Kids> retKList();
        Message1 AddKid(Kids k);
        Kids UpKid(Kids k);
        void DelKid(string s); 
            
    }
}
