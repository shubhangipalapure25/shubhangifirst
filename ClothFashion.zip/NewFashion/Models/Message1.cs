﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewFashion.Models
{
    public class Message1
    {
        public string message { get; set; }
    }
}