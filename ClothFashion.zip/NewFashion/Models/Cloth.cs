﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewFashion.Models
{
    public class Cloth
    {
        [Required]
        public int Cid { get; set; }
        [Required]
        public string Category  { get; set; }
    }
   
}